
package prog_poe5121;

public class Login {
    String Username;
    String Password;
    String firstName;
    String lastName;

    public boolean checkUserName(String Username) {
        if (Username == null) {
            return false;
        }
        return Username.length() <= 5 && Username.contains("_");
    }

    public boolean checkPasswordComplexity(String Password) {
        if (Password == null) {
            return false;
        }
        boolean hasLength = Password.length() >= 8;
        boolean hasUppercase = !Password.equals(Password.toLowerCase());
        boolean hasNumber = Password.matches(".*\\d.*");
        boolean hasSpecial = !Password.matches("[a-zA-Z0-9 ]*");

        return hasLength && hasUppercase && hasNumber && hasSpecial;
    }

    public boolean loginUser(String inputUsername, String inputPassword) {
        if (inputUsername.equals(Username) && inputPassword.equals(Password)) {
            return true;
        } else {
            return false;
        }
    }

    // Method to register a new user
    public String registerUser(String Username, String Password) {
        if (checkPasswordComplexity(Password) && checkUserName(Username)) {
            this.Password = Password;
            this.Username = Username;
            return "Password and Username successfully captured";
        } else {
            return "Password or username is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.";
        }
    }

    public String returnLoginStatus(String Username, String Password) {
        if (Username == null || Password.isEmpty()) {
            return "Please enter both username and password.";
        }

        if (loginUser(Username, Password)) {
            return "Welcome " + firstName + " " + lastName + ". It is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
