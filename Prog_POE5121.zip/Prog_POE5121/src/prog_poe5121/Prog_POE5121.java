package prog_poe5121;

import java.util.Scanner;

public class Prog_POE5121 {

    public static void main(String[] args) {
      
        Login register = new Login();
        Scanner scanner = new Scanner(System.in);
        
        // Register user
        System.out.println("Enter a username to register: ");
        String username = scanner.nextLine();
        
        System.out.println("Enter a password to register: ");
        String password = scanner.nextLine();
        
        String registerUser = register.registerUser(username, password);
        
        if (registerUser.equals("Password and Username successfully captured")) {
            System.out.println(registerUser);
            System.out.println("Welcome to EasyKanban");

            // Collect first name and last name after successful registration
            System.out.println("Enter your first name: ");
            register.firstName = scanner.nextLine();
            
            System.out.println("Enter your last name: ");
            register.lastName = scanner.nextLine();
        } else {
            System.out.println(registerUser);
            return; // Exit the program if registration fails
        }
        
        // Attempt to log in
        System.out.println("Enter your username to login: ");
        String loginUsername = scanner.nextLine();
        
        System.out.println("Enter your password to login: ");
        String loginPassword = scanner.nextLine();
        
        String Status = register.returnLoginStatus(loginUsername, loginPassword);
        System.out.println(Status);
        
            Task create = new Task();
            int choice = create.showOptions();

            switch (choice) {
                case 1:  
                    create.addTasks();
                    break;
                case 2:
                    int options = create.Options();
                    switch (options){
                        case 1:
                            create.Display();
                            break;
                        case 2:
                            create.SearchTask();
                            create.searchDeveloper();
                        case 3:
                            create.Delete();
                    }
                    break;
                case 3:
                    return;
            }
    }

     //reference list
    // 1. A computer science portal for geeks (no date) GeeksforGeeks. Available at: https://www.geeksforgeeks.org/ (Accessed: 30 May 2024). 
    // my loom video link: https://www.loom.com/share/98102853405348349c0c24a107f13aaf?sid=1097beef-bd3c-40c8-85a4-2fd761e97871
    // PROG5121 workshop, Denzyl Govender, 20 June 2024 
    
}