package prog_poe5121;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class LoginTest {
    
    public LoginTest() {
    }
    
    Login login = new Login();

    @Test
    public void testCheckUserName() {
        boolean value = login.checkUserName("kyl_1");
        assertTrue(value);
    }
    
    @Test
    public void testCheckUserNameFalse() {
        boolean value = login.checkUserName("kyle!!!!!!!");
        assertFalse(value);
    }

    @Test
    public void testCheckPasswordComplexity() {
        boolean value = login.checkPasswordComplexity("Ch&&sec@ke99!");
        assertTrue(value);
    }
    
    @Test
    public void testCheckPasswordComplexityFalse() {        
        boolean value = login.checkPasswordComplexity("password");
        assertFalse(value);
    }
    
}
